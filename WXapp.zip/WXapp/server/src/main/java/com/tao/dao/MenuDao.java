package com.tao.dao;

import com.tao.entity.po.MenuList;

public interface MenuDao extends BaseDao<MenuList> {


}
