package com.tao.controller;

import org.springframework.web.bind.annotation.RestController;

/**
 * @Author neotao
 * @Date 2018/9/4
 * @Version V0.0.1
 * @Desc
 */
@RestController
public class MenuController {
    // TODO: 2018/9/4 refactor menu
}
