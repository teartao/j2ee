package com.tao.dao;


import com.tao.entity.po.MenuItemPO;

public interface MenuSelectionDao extends BaseDao<MenuItemPO> {
}
