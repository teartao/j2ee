package com.tao.dao;

import com.tao.entity.po.Order;

public interface OrderDao extends BaseDao<Order> {
}
