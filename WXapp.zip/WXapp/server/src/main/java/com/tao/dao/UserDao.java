package com.tao.dao;

import com.tao.entity.po.User;

public interface UserDao extends BaseDao<User> {

}
