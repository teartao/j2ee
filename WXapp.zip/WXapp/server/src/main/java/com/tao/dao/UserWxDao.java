package com.tao.dao;

import com.tao.entity.WxUser;

public interface UserWxDao extends BaseDao<WxUser> {
}
